#define HEAP


typedef struct {
    int id;
    int vida;
} torre;

//Struc for the heap
typedef struct Heap {
    int tamanho;
    int capacidade;
    torre* vetor;
} Heap;

typedef Heap* p_fp;
typedef torre* p_torre;

p_fp criar_fila_prio(int capacidade);
void insere(p_fp fila, int id, int hp);
torre extrai_minimo(p_fp fila);
void destroi_heap(p_fp fila);
int tamanho_fila();