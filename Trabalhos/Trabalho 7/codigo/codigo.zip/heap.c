#include <stdlib.h>
#include "heap.h"
#define pai(i) ((i-1)/2)
#define filho_esq(i) (2*i+1)
#define filho_dir(i) (2*i+2)

p_fp criar_fila_prio(int capacidade) {
    p_fp fila = (p_fp)malloc(sizeof(Heap));
    fila->tamanho = 0;
    fila->capacidade = capacidade;
    fila->vetor = malloc(capacidade * sizeof(torre));
    return fila;
}

int tamanho_fila(p_fp fila) {
    return fila->tamanho;
}

void insere(p_fp fila, int id, int vida) {
    torre nova;
    nova.id = id;
    nova.vida = vida;
    if (fila->tamanho == fila->capacidade) {
        return;
    }
    fila->vetor[fila->tamanho] = nova;
    fila->tamanho++;
    int i = fila->tamanho - 1;
    while (i > 0 && fila->vetor[pai(i)].vida > fila->vetor[i].vida) {
        torre aux = fila->vetor[i];
        fila->vetor[i] = fila->vetor[pai(i)];
        fila->vetor[pai(i)] = aux;
        i = pai(i);
    }
    return;
}

torre extrai_minimo(p_fp fila) {
    if (fila->tamanho == 0) {
        torre torre;
        torre.id = -1;
        torre.vida = -1;
        return torre;
    }
    torre min = fila->vetor[0];
    fila->vetor[0] = fila->vetor[fila->tamanho - 1];
    fila->tamanho--;
    int i = 0;
    while (filho_esq(i) < fila->tamanho) {
        int menor = filho_esq(i);
        if (filho_dir(i) < fila->tamanho &&
            fila->vetor[filho_dir(i)].vida < fila->vetor[filho_esq(i)].vida) {

            menor = filho_dir(i);
        }
        if (fila->vetor[i].vida > fila->vetor[menor].vida) {
            torre aux = fila->vetor[i];
            fila->vetor[i] = fila->vetor[menor];
            fila->vetor[menor] = aux;
            i = menor;
        }
        else {
            break;
        }
    }
    return min;
}

void destroi_heap(p_fp fila) {
    free(fila->vetor);
    free(fila);
}
